# display

A Pen created on CodePen.

Original URL: [https://codepen.io/Raldino-Aldi/pen/LEYxYgd](https://codepen.io/Raldino-Aldi/pen/LEYxYgd).

untuk stik